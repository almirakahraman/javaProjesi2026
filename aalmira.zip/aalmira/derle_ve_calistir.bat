@echo off
REM ============================================================
REM  Akilli Sehir Lojistik Simulasyonu - Derle ve Calistir
REM  Bu betik projeyi derler (src -> out) ve Main sinifini calistirir.
REM ============================================================
chcp 65001 >nul
setlocal

REM JDK yolunu otomatik bul (Microsoft OpenJDK). Gerekirse asagidaki satiri kendi yolunuzla degistirin.
set "JDK=C:\Program Files\Microsoft\jdk-21.0.11.10-hotspot"

if not exist "%JDK%\bin\javac.exe" (
  echo [HATA] JDK bulunamadi: %JDK%
  echo Lutfen JDK yolunu bu .bat dosyasinin icindeki JDK degiskeninde guncelleyin.
  pause
  exit /b 1
)

echo --- Derleniyor... ---
dir /s /b src\*.java > sources.txt
"%JDK%\bin\javac.exe" -encoding UTF-8 -d out @sources.txt
del sources.txt

if errorlevel 1 (
  echo [HATA] Derleme basarisiz.
  pause
  exit /b 1
)

echo --- Calistiriliyor... ---
echo.
"%JDK%\bin\java.exe" "-Dfile.encoding=UTF-8" -cp out lojistik.Main

echo.
pause
endlocal
